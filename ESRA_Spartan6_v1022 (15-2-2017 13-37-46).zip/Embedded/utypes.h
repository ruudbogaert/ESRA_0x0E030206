// processdata structures and global user defined types

#include "config.h"
#define float32   float

#ifndef PACKED
#define PACKED                  __packed__
#endif

typedef union PACKED
  {
    uint16_t w;
    uint8_t  b[2];
  } uint16union_t;

typedef union PACKED
{
    float32 number;
    uint8_t b[4];
} float32union_t;

#define APPSTATE_IDLE       0x00
#define APPSTATE_INPUT      0x01
#define APPSTATE_OUTPUT     0x02

// size for setpoint and current buffers in FRF operation mode
#define FRFBUFFERSIZE       22

// mstate
// bit 0 : enabled
// bit 1 : DRV fault
// bit 2 : DRV over temp warning

// Bit definitions serial bridge control and status words

#define SER_MAXBUF          22

// Transmit accepted toggle
#define SSTAT_TA            0x0001
// Receive request toggle
#define SSTAT_RR            0x0002
// Init accepted
#define SSTAT_IA            0x0004
// Receive buffer full
#define SSTAT_RXFULL        0x0008
// Input length mask
#define SSTAT_IL_MASK       0xff00

// Transmit request toggle
#define SCON_TR             0x0001
// Receive accepted toggle
#define SCON_RA             0x0002
// Init request
#define SCON_IR             0x0004
// Send continuous
#define SCON_SC             0x0008
// Output length mask
#define SCON_OL_MASK        0xff00

typedef struct PACKED{
  uint8_t       mstate1;
  uint32_t      count1;
  uint32_t      timestamp1;
  int16_t       velocity1;
  int16_t       current1;
  uint8_t       mstate2;
  uint32_t      count2;
  uint32_t      timestamp2;
  int16_t       velocity2;
  int16_t       current2;
  uint8_t       mstate3;
  uint32_t      count3;
  uint32_t      timestamp3;
  int16_t       velocity3;
  int16_t       current3;
  uint8_t       digital;
  uint16_t      caliper1;
  uint16_t      caliper2;
  uint16_t      force1;
  uint16_t      force2;
  uint16_t      force3;
  uint16_t      pos1;
  uint16_t      pos2;
  uint16_t      pos3;
  uint16_t      analog1;
  uint16_t      analog2;
  uint16_t      linevoltage;
  uint16_t      ectime;
  uint16_t      sstatus;
  uint8_t       srxbuf[SER_MAXBUF];
}txpdo1_t;

typedef struct PACKED{
  uint8_t       mstate;
  uint8_t       buffer;
  uint8_t       entries;
  uint16_t      ectime;
  int16_t       current[FRFBUFFERSIZE];
}txpdo2_t;

#define MCOM_ENABLE           0x01
#define MCOM_TRISTATE         0x02
#define MCOM_FRF_MMASK        0x03
#define MCOM_FRF_ENABLE       0x04
#define MCOM_FRF_TRISTATE     0x08

typedef struct PACKED{
  uint8_t       mcom1;
  int16_t       setpoint1;
  int16_t       ff1;
  uint8_t       mcom2;
  int16_t       setpoint2;
  int16_t       ff2;
  uint8_t       mcom3;
  int16_t       setpoint3;
  int16_t       ff3;
  uint8_t       digital;
  int16_t       aout1;
  int16_t       aout2;
  uint16_t      scontrol;
  uint8_t       stxbuf[SER_MAXBUF];
}rxpdo1_t;

typedef struct PACKED{
  uint8_t       mcom;
  uint8_t       entries;
  int16_t       setpoint[FRFBUFFERSIZE];
}rxpdo2_t;

typedef struct PACKED{
  float         m1r;
  float         m1kv;
  float         m1pgain;
  float         m1igain;
  float         m1ilimit;
  int8_t        m1encdir;
  uint16_t      m1encres;
  int16_t       m1czero;
  float         m2r;
  float         m2kv;
  float         m2pgain;
  float         m2igain;
  float         m2ilimit;
  int8_t        m2encdir;
  uint16_t      m2encres;
  int16_t       m2czero;
  float         m3r;
  float         m3kv;
  float         m3pgain;
  float         m3igain;
  float         m3ilimit;
  int8_t        m3encdir;
  uint16_t      m3encres;
  int16_t       m3czero;
  uint32_t      baudrate;
}param_t;

typedef struct PACKED{
  uint16_t      v5;
  uint16_t      v12;
  uint16_t      v1_2;
  uint16_t      v1_65;
}ivalue_t;

extern txpdo1_t        txpdo1;
extern txpdo2_t        txpdo2;
extern rxpdo1_t        rxpdo1;
extern rxpdo2_t        rxpdo2;
extern param_t         param;
extern ivalue_t        ivalue;
extern uint8_t         Ec_state;
extern uint8_t         txpdoentries, rxpdoentries;
extern uint16_t        txpdoindex, rxpdoindex;
extern uint16_t        ec_txpdoindex, ec_rxpdoindex;

#if !defined(EC_BIG_ENDIAN) && defined(EC_LITTLE_ENDIAN)

  #define htoes(A) (A)
  #define htoel(A) (A)
  #define htoell(A) (A)
  #define etohs(A) (A)
  #define etohl(A) (A)
  #define etohll(A) (A)

#elif !defined(EC_LITTLE_ENDIAN) && defined(EC_BIG_ENDIAN)

  #define htoes(A) ((((uint16_t)(A) & 0xff00) >> 8) | \
                    (((uint16_t)(A) & 0x00ff) << 8))
  #define htoel(A) ((((uint32_t)(A) & 0xff000000) >> 24) | \
                    (((uint32_t)(A) & 0x00ff0000) >> 8)  | \
                    (((uint32_t)(A) & 0x0000ff00) << 8)  | \
                    (((uint32_t)(A) & 0x000000ff) << 24))
  #define htoell(A) ((((uint64_t)(A) & (uint64_t)0xff00000000000000ULL) >> 56) | \
                     (((uint64_t)(A) & (uint64_t)0x00ff000000000000ULL) >> 40) | \
                     (((uint64_t)(A) & (uint64_t)0x0000ff0000000000ULL) >> 24) | \
                     (((uint64_t)(A) & (uint64_t)0x000000ff00000000ULL) >> 8)  | \
                     (((uint64_t)(A) & (uint64_t)0x00000000ff000000ULL) << 8)  | \
                     (((uint64_t)(A) & (uint64_t)0x0000000000ff0000ULL) << 24) | \
                     (((uint64_t)(A) & (uint64_t)0x000000000000ff00ULL) << 40) | \
                     (((uint64_t)(A) & (uint64_t)0x00000000000000ffULL) << 56))

  #define etohs  htoes
  #define etohl  htoel
  #define etohll htoell

#else

  #error "Must define one of EC_BIG_ENDIAN or EC_LITTLE_ENDIAN"

#endif
