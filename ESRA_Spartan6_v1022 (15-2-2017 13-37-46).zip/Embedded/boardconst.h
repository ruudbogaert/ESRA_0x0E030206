// TUeES30 3 axis DC motor controller
// Board constants

// fixed point Q8 multiplier
#define Q8f       256.0f

// interrupt from PWM->ADC verilog module
#define INTPWM          2
// interrupt from verilog ethercat timer
#define INTEC           3

// board reference voltage for ADC converters
#define VREF            3.3f
// resolution in steps of the ADC converters
#define ADCRESOLUTION   4096

// current shunt resistor value in ohm
#define RESISTOR        0.082f
// gain of the current shunt amplifier
#define IMGAIN          20.0f
// current shunt to voltage gain
#define I2U             RESISTOR * IMGAIN
// current shunt to voltage gain for channel 1 (2 shunts in parallel)
#define I2UCH1          RESISTOR * 0.5f * IMGAIN
// voltage to bits gain for ADC
#define U2BIT           (ADCRESOLUTION / VREF)
// current in mA to bits (CH2 + CH3)
#define I2RGAIN         (I2U * U2BIT * 0.001f)
// bits to current in mA (CH2 + CH3)
#define R2IGAIN         (1000.0f / (I2U * U2BIT))
// current in mA to bits (CH1)
#define I2RGAINCH1      (I2UCH1 * U2BIT * 0.001f)
// bits to current in mA (CH1)
#define R2IGAINCH1      (1000.0f / (I2UCH1 * U2BIT))

// maximum allowed control voltage, 2V above zener clamping voltage
#define MAXVOLTAGE      (int16_t)(34.0f * 100.0f)
// voltage where to kill current control and switch to break mode
#define KILLVOLTAGE      (int16_t)(34.0f / R2U)

// maximum allowed PWM duty cycle (to prevent narrow spikes)
#define MAXCONTROL       (int16_t)(PWMPER * 0.98)
// minimum allowed PWM duty cycle (to prevent narrow spikes)
#define MINCONTROL       (int16_t)(PWMPER * 0.02)
// half PWM duty cycle
#define HALFPWM          (int16_t)(PWMPER * 0.5)

// linevoltage calculation
// resistor divider R1 and R2 in ohms
// UR1 is in the top, UR2 is in the bottom of the divider chain
#define UR1              47000.0f
#define UR2              4700.0f

// bits to voltage gain
#define R2U              ((VREF * (UR1 + UR2)) / (ADCRESOLUTION * UR2))
// bits to voltage gain in fixed point Q8, result in 10mV units
#define R2U_FP           (R2U * 100.0f * Q8f)


