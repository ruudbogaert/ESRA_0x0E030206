void foe_init(void);
