extern volatile int          rx_counter;
extern volatile int          tx_counter;

void rx_buffer_write(int16_t value);
int16_t rx_buffer_read(void);
int rxfree(void);
int16_t tx_buffer_read(void);
void tx_buffer_write(int16_t value);

