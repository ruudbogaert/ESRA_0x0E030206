// TUeES30 3 axis DC motor controller
// MAIN control program
//
// Version : 2.0
// (c) Arthur Ketels 2015-2016

#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <swplatform.h>
#include "utypes.h"
#include "esc.h"
#include "esc_coe.h"
#include "esc_foe.h"
#include "version.h"
#include "hardware.h"
#include "vmodules.h"
#include "boardconst.h"
#include "circbuffer.h"
#include "caliper.h"
#include "filetransfer.h"
#include "serial.h"

// default mode of operation (current controller, 3 axes)
#define OPERATION_STD   0
// FRF mode of operation (current controller, 1 axis, high speed buffer)
#define OPERATION_FRF   1

// CPU clock frequency
#define CPU_CLK         40000000
// PWM module base frequency
#define PWM_CLK         100000000
// PWM cycle frequency
#define PWMFREQ         80000
// PWM period in base frequency units (triangle shape counter)
#define PWMPER          (PWM_CLK / (PWMFREQ * 2))
// EtherCAT service frequency
#define SERVICEFREQ     1000
// service period
#define SERVICEPER      (CPU_CLK / SERVICEFREQ)
// delta time limit for velocity calculation
// lower delta time captures are regarded as noise
#define VELTIMELIMIT    (CPU_CLK / (SERVICEFREQ * 4))
// lowest line voltage to compensate PWM for in 10mV units
#define LINEVOLTAGELIMIT 1000

// standard set of math constants
#define PI_FLOAT        3.1415926535897f
#define PIBY2_FLOAT     1.5707963f
#define RAD2DEG         (180.0f / PI_FLOAT)
#define DEG2RAD         (PI_FLOAT / 180.0f)
#define GRAW2GRAD       (2000.0f / 32768.0f)
#define GRAW2RAD        (GRAW2GRAD * DEG2RAD)

// digital IO bit defines
#define DRVENA1      1
#define DRVENA2      2
#define DRVENA3      4
#define DOSPARE1     1
#define DOSPARE2     2
#define DOSPARE3     4
#define DOSPARE4     8
#define FRUN         0x80
#define M1_FAULT     0x10
#define M1_OTW       0x20
#define M2_M3_FAULT  0x10
#define M2_M3_OTW    0x20
#define DIGINMASK    0x0f

// serial bridge states and limits
#define SERSM_IDLE        0
#define SERSM_READY       1
#define SERSM_TRANS       2
#define SERSM_ACK         3
#define MINBAUDRATE       1200
#define MAXBAUDRATE       1000000

// Extern used global variables
volatile _ESCvar                    ESCvar;
_MBX                                MBX[MBXBUFFERS];
_MBXcontrol                         MBXcontrol[MBXBUFFERS];
uint8_t                             MBXrun = 0;
uint16_t                            SM2_sml, SM3_sml;
txpdo1_t                            txpdo1;
txpdo2_t                            txpdo2;
rxpdo1_t                            rxpdo1;
rxpdo2_t                            rxpdo2;
_App                                App;
uint16_t                            TXPDOsize, RXPDOsize;
uint8_t                             Ec_state;
param_t                             param;
ivalue_t                            ivalue;
uint8_t                             txpdoentries = 0x01;
uint8_t                             rxpdoentries = 0x01;
uint16_t                            txpdoindex = 0x1a00;
uint16_t                            rxpdoindex = 0x1600;
uint16_t                            ec_txpdoindex = htoes(0x1a00);
uint16_t                            ec_rxpdoindex = htoes(0x1600);

typedef struct {
  // current setpoint in 1mA untis
  int16_t      current_setpoint;
  // actual measured current in 1mA units
  int16_t      current;
  // in 10mV units
  int16_t      backemf_ff;
  // in 10mV units
  int16_t      setpoint_ff;
  // in increments
  int32_t      position, prev_position;
  // capture times in CPU_CLK units (40MHz)
  int32_t      poscaptime, prev_poscaptime;
  // in 0.1rad/s units
  int16_t      velocity;
  // current controller
    // proportional gain in q8
    int16_t      cc_pgain;
    // integral gain in q8
    int16_t      cc_igain;
    // control error in 1mA units
    int16_t      cc_error;
    // integral wind-up limiter value
    int32_t      cc_ilimit;
    // integral of cc_error
    int32_t      cc_integral;
    // computed output of PI controller in 10mV units
    int16_t      cc_control;
    // computed output in PWM units
    int16_t      cc_pwm;
  // flags
    // encoder direction
    int          encoder_dir;
    // flag if current controller wind-up limiter is active
    int          cc_isclipped;
    // pwm enabled flag
    int          enabled;
    // disabled mode
    int          tristate;
  // motor constants
    // Q8 motor resistance to voltage, input in 1mA, output in 10mV
    int16_t     rm2u;
    // Q8 motor KV to voltage, input velocity in 0.1rad/s, output in 10mV
    int16_t     kvmotor;
    // encoder increments per revolution
    uint16_t    encoderincrements;
} motor_t;

// Global variables
static motor_t        motor[3];
static int16_t        linevoltage_i;
static uint16_t       icnt;
static uint16_t       zero_current1;
static uint16_t       zero_current2;
static uint16_t       zero_current3;
static int16_t        u2pwm;
static int            operationmode;
static int            isclipped;
static uint8_t        enastate, dostate;
static volatile int   wd_cnt;
static int            wd_resetvalue = 100;
static int            wd_trigger;
static uint8_t        frfchannel;
static uint32_t       ser_baudrate;
static uart8_parity_t ser_parity;
static uint8_t        ser_wordlen, ser_stopbits;

static void clear_actuators(void);
static void param2int(void);

inline uint8_t read_digin(void)
{
  return IOPORT_BASE8(GPIO_1_BASE_ADDRESS)[GPIO_1_DI];
}

inline void cpy_digout(uint8_t pos)
{
  IOPORT_BASE8(GPIO_1_BASE_ADDRESS)[GPIO_1_DO] = pos;
}

inline void set_digout(uint8_t pos)
{
  dostate |= pos;
  IOPORT_BASE8(GPIO_1_BASE_ADDRESS)[GPIO_1_DO] = dostate;
}

inline void clear_digout(uint8_t pos)
{
  dostate &= ~(pos);
  IOPORT_BASE8(GPIO_1_BASE_ADDRESS)[GPIO_1_DO] = dostate;
}

inline void toggle_digout(uint8_t pos)
{
  dostate ^= pos;
  IOPORT_BASE8(GPIO_1_BASE_ADDRESS)[GPIO_1_DO] = dostate;
}

inline void set_drvena(uint8_t pos)
{
  enastate |= pos;
  IOPORT_BASE8(GPIO_1_BASE_ADDRESS)[GPIO_1_DRVENA] = enastate;
}

inline void clear_drvena(uint8_t pos)
{
  enastate &= ~(pos);
  IOPORT_BASE8(GPIO_1_BASE_ADDRESS)[GPIO_1_DRVENA] = enastate;
}

inline void toggle_drvena(uint8_t pos)
{
  enastate ^= pos;
  IOPORT_BASE8(GPIO_1_BASE_ADDRESS)[GPIO_1_DRVENA] = enastate;
}

void ESC_objecthandler (uint16_t index, uint8_t subindex)
{
   switch (index)
   {
      case 0x1c12:
      {
         if (rxpdoentries > 1)
         {
            rxpdoentries = 1;
         }
         if(subindex == 01)
         {
            rxpdoindex = htoes(ec_rxpdoindex);
         }
         if ((rxpdoindex != 0x1600) && (rxpdoindex != 0x1601)
             && (rxpdoindex != 0x0000))
         {
            rxpdoindex = 0x1600;
            ec_rxpdoindex = htoes(rxpdoindex);
         }
         RXPDOsize = SM2_sml = sizeRXPDO();
         break;
      }
      case 0x1c13:
      {
         if (txpdoentries > 1)
         {
            txpdoentries = 1;
         }
         if(subindex == 01)
         {
            txpdoindex = htoes(ec_txpdoindex);
         }
         if ((txpdoindex != 0x1A00) && (txpdoindex != 0x1A01)
             && (rxpdoindex != 0x0000))
         {
            txpdoindex = 0x1A00;
            ec_txpdoindex = htoes(txpdoindex);
         }
         TXPDOsize = SM3_sml = sizeTXPDO();
         break;
      }
      case 0x8000:
      case 0x8001:
      case 0x8002:
      {
         // convert parameters to internal values
         param2int();
      }
   }
}

/** Hook called after state change for application specific
 * actions for specific state changes.
 */
void post_state_change_hook (uint8_t * as, uint8_t * an)
{
   // check process data definition when going from preop to safeop
   if ((*as == PREOP_TO_SAFEOP) && (*an == ESCsafeop))
   {
     if((txpdoindex == 0x1a00) && (rxpdoindex == 0x1600))
     {
       operationmode = OPERATION_STD;
       TIM_SYNCENA = 1;
     }
     else if((txpdoindex == 0x1a01) && (rxpdoindex == 0x1601))
     {
       operationmode = OPERATION_FRF;
       TIM_SYNCENA = 1;
     }
     else
     {
        // unsupported procesdata combination
        ESC_ALstatus(ESCpreop + ESCerror);
        ESC_ALerror (ALERR_INVALIDSMCONFIG);
     }
   }
   else if ((*an == ESCpreop) || (*an == ESCinit))
   {
      TIM_SYNCENA = 0;
   }
}

static inline int16_t htoes2(int16_t inval)
{
  SWAP_IN = inval;
  return (int16_t)SWAP_OUT16;
}

static inline int32_t htoel2(int32_t inval)
{
  SWAP_IN = inval;
  return SWAP_OUT32;
}

static inline float htoef2(float inval)
{
  SWAP_INF = inval;
  return SWAP_OUTF;
}

static void read_ADC(void)
{
  uint16_t ADC;
  int16_t  ADC_current;

  ADC = ADC1_CH0;
  txpdo1.force1    = htoes2(ADC);
  ADC = ADC1_CH1;
  txpdo1.pos1      = htoes2(ADC);
  ADC = ADC1_CH2;
  txpdo1.force2    = htoes2(ADC);
  ADC = ADC1_CH3;
  txpdo1.pos2      = htoes2(ADC);
  ADC = ADC1_CH4;
  txpdo1.force3    = htoes2(ADC);
  ADC = ADC1_CH5;
  txpdo1.pos3      = htoes2(ADC);
  ADC_current = motor[0].current;
  txpdo1.current1  = htoes2(ADC_current);
  ADC_current = motor[1].current;
  txpdo1.current2  = htoes2(ADC_current);
  ADC_current = motor[2].current;
  txpdo1.current3  = htoes2(ADC_current);
  ADC = ADC1_CH6;
  txpdo1.analog1   = htoes2(ADC);
  ADC = ADC1_CH7;
  txpdo1.analog2   = htoes2(ADC);
  ADC = ADC2_CH0;
  ivalue.v5        = htoes2(ADC);
  ADC = ADC2_CH1;
  ivalue.v12       = htoes2(ADC);
  ADC = ADC2_CH6;
  ivalue.v1_2      = htoes2(ADC);
  ADC = ADC2_CH7;
  ivalue.v1_65     = htoes2(ADC);
}

// clip int16 between low and high value
static inline int16_t clip16(int16_t val, int16_t clipl, int16_t cliph)
{
    if(val < clipl)
    return clipl;
    else if(val > cliph)
    return cliph;
    return val;
}

// fixed point int16 x q16.8 multiply, int16 result
static inline int16_t q8mul(int16_t value, int16_t mul)
{
    int32_t res;
    res = ((int32_t)(value) * mul) >> 8;
    if (res > 32767)
    res = 32767;
    if (res < -32768)
    res = -32768;
    return (int16_t)res;
}

// fixed point int16 x q16.8 multiply, int32 result
static inline int32_t q8mul32(int32_t value, int16_t mul)
{
    int32_t res;
    res = ((int32_t)(value) * mul) >> 8;
    return (int16_t)res;
}

// clip int32 between low and high value
// isclipped is 1 when value has been clipped
static inline int32_t clip32(int32_t val, int32_t clipl, int32_t cliph)
{
    if(val < clipl)
    {
        isclipped = 1;
        return clipl;
    }
    else if(val > cliph)
    {
        isclipped = 1;
        return cliph;
    }
    isclipped = 0;
    return val;
}

// all PWM channels set to zero
static void clear_PWM(void)
{
  PWM_LOCK = 1;
  PWM_CMP1A = 0;
  PWM_CMP1B = 0;
  PWM_CMP2A = 0;
  PWM_CMP2B = 0;
  PWM_CMP3A = 0;
  PWM_CMP3B = 0;
  PWM_LOCK = 0;
}

static void init_PWM(void)
{
  PWM_TOP = PWMPER;
  clear_PWM();
  PWM_ENA = 1;
  set_drvena(DRVENA1 | DRVENA2 | DRVENA3);
}

// update PWM channels using 50% strategy
// zero output is 50% PWM on both (A and B) half bridges (in phase)
// negative output lowers PWM on A and increases on B
// positive output increases PWM on A and lowers on B
// LSB of setpoint is modulated only on half bridge A (effectivly increasing resolution by one bit)
static inline void update_PWM(void)
{
  int16_t pwm;
  uint16_t pwma, pwmb, half;

  pwm       = motor[0].cc_pwm;
  half      = (pwm & 0x0001);
  pwm       = pwm >> 1;
  pwma      = HALFPWM + pwm + half;
  pwmb      = HALFPWM - pwm;
  PWM_LOCK  = 1;
  PWM_CMP1A = pwma;
  PWM_CMP1B = pwmb;
  PWM_LOCK  = 0;
  pwm       = motor[1].cc_pwm;
  half      = (pwm & 0x0001);
  pwm       = pwm >> 1;
  pwma      = HALFPWM + pwm + half;
  pwmb      = HALFPWM - pwm;
  PWM_LOCK  = 1;
  PWM_CMP2A = pwma;
  PWM_CMP2B = pwmb;
  PWM_LOCK  = 0;
  pwm       = motor[2].cc_pwm;
  half      = (pwm & 0x0001);
  pwm       = pwm >> 1;
  pwma      = HALFPWM + pwm + half;
  pwmb      = HALFPWM - pwm;
  PWM_LOCK  = 1;
  PWM_CMP3A = pwma;
  PWM_CMP3B = pwmb;
  PWM_LOCK  = 0;
}

static void read_encoders(void)
{
  txpdo1.count1     = htoel2(motor[0].position);
  txpdo1.timestamp1 = htoel2(motor[0].poscaptime);
  txpdo1.velocity1  = htoes2(motor[0].velocity);
  txpdo1.count2     = htoel2(motor[1].position);
  txpdo1.timestamp2 = htoel2(motor[1].poscaptime);
  txpdo1.velocity2  = htoes2(motor[1].velocity);
  txpdo1.count3     = htoel2(motor[2].position);
  txpdo1.timestamp3 = htoel2(motor[2].poscaptime);
  txpdo1.velocity3  = htoes2(motor[2].velocity);
}

static inline void waitready_DAC(void)
{
  if (!DAC_DONE) delay_us(2);
}

static inline void write_DAC(uint32_t data0, uint32_t data1)
{
  DAC_START = 0;
  DAC_DATA0 = data0;
  DAC_DATA1 = data1;
  DAC_START = 1;
}

static void init_DAC(void)
{
  DAC_DIV = 0;                   // div by 2 40Mhz->20Mhz SCLK
  write_DAC(0x0c0001, 0x0c0001); // dac gain = 4 -> 0..10V
  waitready_DAC();
  write_DAC(0x100005, 0x190006); // power on and set 20mA limit
  waitready_DAC();
  write_DAC(0x008000, 0x028000); // default mid output
  waitready_DAC();
}

static inline void update_DAC(void)
{
  waitready_DAC();
  write_DAC(0x000000 | (clip16(2048 + htoes2(rxpdo1.aout1), 0, 4095) << 4),
            0x020000 | (clip16(2048 + htoes2(rxpdo1.aout2), 0, 4095) << 4));
}

static void init_actuators(void)
{
  set_digout(0);
  init_DAC();
  init_PWM();
}

static inline void update_actuators(void)
{
  motor[0].current_setpoint = htoes2(rxpdo1.setpoint1);
  motor[0].setpoint_ff      = clip16(htoes2(rxpdo1.ff1), -MAXVOLTAGE, MAXVOLTAGE);
  motor[0].enabled          = rxpdo1.mcom1 & MCOM_ENABLE;
  motor[0].tristate         = rxpdo1.mcom1 & MCOM_TRISTATE;
  motor[1].current_setpoint = htoes2(rxpdo1.setpoint2);
  motor[1].setpoint_ff      = clip16(htoes2(rxpdo1.ff2), -MAXVOLTAGE, MAXVOLTAGE);
  motor[1].enabled          = rxpdo1.mcom2 & MCOM_ENABLE;
  motor[1].tristate         = rxpdo1.mcom2 & MCOM_TRISTATE;
  motor[2].current_setpoint = htoes2(rxpdo1.setpoint3);
  motor[2].setpoint_ff      = clip16(htoes2(rxpdo1.ff3), -MAXVOLTAGE, MAXVOLTAGE);
  motor[2].enabled          = rxpdo1.mcom3 & MCOM_ENABLE;
  motor[2].tristate         = rxpdo1.mcom3 & MCOM_TRISTATE;
  cpy_digout((rxpdo1.digital & 0x0f) | (dostate & 0xf0));
  update_DAC();
}

static void init_sensors(void)
{
  ENC1_ENA = 0;
  ENC2_ENA = 0;
  ENC3_ENA = 0;
  ENC1_ENA = 1;
  ENC2_ENA = 1;
  ENC3_ENA = 1;
}

static inline void reset_wd(void)
{
  wd_cnt = wd_resetvalue;
  wd_trigger = 0;
}

static void ser_statemachine(void)
{
  static int rxstate, txstate;
  uint16_t scon, sstat;
  static int tl, pt;
  static int rl, pr;

  scon = etohs(rxpdo1.scontrol);
  sstat = etohs(txpdo1.sstatus);
  if((scon & SCON_IR) && !(sstat & SSTAT_IA))
  {
    sstat = SSTAT_IA;
    uart_reset();
    ser_baudrate = etohl(param.baudrate);
    if(ser_baudrate < MINBAUDRATE) ser_baudrate = MINBAUDRATE;
    if(ser_baudrate > MAXBAUDRATE) ser_baudrate = MAXBAUDRATE;
    ser_parity = UART8_NO_PARITY;
    ser_wordlen = 8;
    ser_stopbits = 1;
    uart8_set_parameters(SERDRV, ser_baudrate, ser_parity, ser_wordlen, ser_stopbits);
    rxstate = txstate = SERSM_IDLE;
  }
  else if(!(scon & SCON_IR) && (sstat & SSTAT_IA))
  {
    rxstate = txstate = SERSM_READY;
    sstat &= ~SSTAT_IA;
  }
  if((txstate == SERSM_READY) && ((scon & SCON_TR) != (sstat & SSTAT_TA)))
  {
    tl = (scon & SCON_OL_MASK) >> 8;
    if(tl > SER_MAXBUF) tl = SER_MAXBUF;
    pt = 0;
    txstate = SERSM_TRANS;
  }
  if(txstate == SERSM_TRANS)
  {
    while(tl && uart_txfree())
    {
      uart_putchar(rxpdo1.stxbuf[pt++]);
      tl--;
    }
    if(!tl)
    {
      txstate = SERSM_READY;
      sstat ^= SSTAT_TA;
    }
  }
  if((rxstate == SERSM_READY) && rx_counter_usart && ((scon & SCON_RA) == (sstat & SSTAT_RR)))
  {
    rl = rx_counter_usart;
    if(rl > SER_MAXBUF) rl = SER_MAXBUF;
    sstat = (sstat & ~SSTAT_IL_MASK) | (rl << 8);
    pr = 0;
    while(rl)
    {
      txpdo1.srxbuf[pr++] = uart_getchar();
      rl--;
    }
    sstat ^= SSTAT_RR;
    rxstate = SERSM_TRANS;
  }
  if((rxstate == SERSM_TRANS) && ((scon & SCON_RA) == (sstat & SSTAT_RR)))
  {
    rxstate = SERSM_READY;
  }
  if((rxstate > SERSM_IDLE) && rx_buffer_overflow_usart)
  {
    sstat |= SSTAT_RXFULL;
  }
  txpdo1.sstatus = htoes(sstat);
}

static void handle_RXPDO(void)
{
  int count, i;
  uint8_t tmpu8;
  if(App.state & APPSTATE_OUTPUT)
  {
    if(ESCvar.ALevent & ESCREG_ALEVENT_SM2)
    {
      if(operationmode == OPERATION_STD)
      {
        // reading RXPDO clears ESCREG_ALEVENT_SM2
        ESC_read(SM2_sma,(uint8_t*)&rxpdo1,RXPDOsize,(uint8_t*)&ESCvar.ALevent);
        update_actuators();
        ser_statemachine();
      }
      // operation mode FRF
      else
      {
        // reading RXPDO clears ESCREG_ALEVENT_SM2
        ESC_read(SM2_sma, (uint8_t*)&rxpdo2,RXPDOsize,(uint8_t*)&ESCvar.ALevent);
        // use intermediate varable to prevent race condition with i_handler_pwm
        // mcom : bit 0..1 = motor channel , bit 2 = enable , bit 3 = tristate active
        tmpu8 = rxpdo2.mcom & MCOM_FRF_MMASK;
        if(tmpu8 > 2) tmpu8 = 2;
        frfchannel = tmpu8;
        if(frfchannel != 0) motor[0].enabled = 0;
        if(frfchannel != 1) motor[1].enabled = 0;
        if(frfchannel != 2) motor[2].enabled = 0;
        if(rxpdo2.mcom & MCOM_FRF_ENABLE)
          motor[frfchannel].enabled  = MCOM_ENABLE;
        else
          motor[frfchannel].enabled  = 0;
        if(rxpdo2.mcom & MCOM_FRF_TRISTATE)
          motor[frfchannel].tristate = MCOM_TRISTATE;
        else
          motor[frfchannel].tristate = 0;
        count = rxpdo2.entries;
        if(count > FRFBUFFERSIZE) count = FRFBUFFERSIZE;
        for(i=0; i < count ; i++)
        {
          if(rxfree() > 0)
            rx_buffer_write(htoes2(rxpdo2.setpoint[i]));
        }
      }
      reset_wd();
    }
    // watchdog time has elapsed?
    if(!wd_cnt)
    {
      ESC_stopoutput();
      // watchdog, invalid outputs
      ESC_ALerror(ALERR_WATCHDOG);
      // goto safe-op with error bit set
      ESC_ALstatus(ESCsafeop | ESCerror);
      wd_trigger = 1;
    }
  }
  else
  {
    reset_wd();
  }
}

static void handle_TXPDO(void)
{
  int16_t temp;
  uint8_t di;
  unsigned int txbufferentries;
  uint8_t c;
  uint16_t cc;

  if(App.state & APPSTATE_INPUT){
    if(operationmode == OPERATION_STD)
    {
      read_encoders();
      read_calipers();
      read_ADC();
      di = read_digin();
      // bit 0 : enabled
      // bit 1 : DRV fault
      // bit 2 : DRV over temp warning
      txpdo1.mstate1 = (uint8_t)motor[0].enabled | ((di & (M1_FAULT | M1_OTW)) >> 3);
      // motor 2 and 3 have common driver and therefore common faults
      txpdo1.mstate2 = (uint8_t)motor[1].enabled | ((di & (M2_M3_FAULT | M2_M3_OTW)) >> 5);
      txpdo1.mstate3 = (uint8_t)motor[2].enabled | ((di & (M2_M3_FAULT | M2_M3_OTW)) >> 5);
      txpdo1.linevoltage = htoes2(linevoltage_i);
      txpdo1.digital = di & DIGINMASK;
//      while(rx_counter_usart && !rx_busy_usart)
//      {
//        c = uart_getchar();
//        cc = c;
//        txpdo1.sstatus = htoes(cc);
//        uart_putchar(c);
//      }
      ESC_write(SM3_sma,(uint8_t*)&txpdo1,TXPDOsize,(uint8_t*)&ESCvar.ALevent);
    }
    else
    {
      // make TXPDO SM3 synced in OP state, or free-run in SAFE-OP state
      if((ESCvar.ALevent & ESCREG_ALEVENT_SM3) || !(App.state & APPSTATE_OUTPUT))
      {
        txbufferentries = 0;
        while((tx_counter > 0) && (txbufferentries < FRFBUFFERSIZE))
        {
           temp = tx_buffer_read();
           txpdo2.current[txbufferentries++] = htoes2(temp);
        }
        txpdo2.entries = (uint8_t)txbufferentries;
        di = read_digin();
        txpdo2.mstate = (uint8_t)(motor[0].enabled | motor[1].enabled | motor[2].enabled) |
                        ((di & (M1_FAULT | M1_OTW)) >> 3) |
                        ((di & (M2_M3_FAULT | M2_M3_OTW)) >> 5);
        txpdo2.buffer = (uint8_t)rx_counter;
        // writing TXPDO clears ESCREG_ALEVENT_SM3
        ESC_write(SM3_sma,(uint8_t*)&txpdo2,TXPDOsize,(uint8_t*)&ESCvar.ALevent);
      }
    }
  }
}

static void currentPI(motor_t *motor)
{
    // current control error
    motor->cc_error = motor->current_setpoint - motor->current;
    // integrator, wind up limited if PWM saturates
    if(!motor->cc_isclipped)
    {
      motor->cc_integral = clip32(motor->cc_integral + motor->cc_error, -motor->cc_ilimit, motor->cc_ilimit);
    }
    // PI controller : control = ((PGAIN * i_err) + (IGAIN * i_i))
    // clipped at maxvoltage
    motor->cc_control = (int16_t)clip32(q8mul32(motor->cc_error, motor->cc_pgain)
                                      + q8mul32((motor->cc_integral >> 6), motor->cc_igain)
                                   , -MAXVOLTAGE, MAXVOLTAGE);
    // transform to pwm duty cycle clipped at MAXCONTROL
    motor->cc_pwm = (int16_t)clip16(q8mul(motor->cc_control +
                                          motor->backemf_ff +
                                          motor->setpoint_ff +
                                          q8mul(motor->current_setpoint, motor->rm2u)
                                          , u2pwm), -MAXCONTROL, MAXCONTROL);
    // clip16 isclipped result is copied in motor struct to prevent integral wind-up
    motor->cc_isclipped = isclipped;
}

// v1003 : 15us total run time at 40MHz
__INTERRUPT_NATIVE void i_handler_pwm(void)
{
  int16_t adc_current1, adc_current2, adc_current3;
  adc_current1 = ADC2_CH3 - zero_current1;
  adc_current2 = ADC2_CH4 - zero_current2;
  adc_current3 = ADC2_CH5 - zero_current3;
  // convert ADC current units to 1mA units
  motor[0].current = q8mul(adc_current1, (int16_t)(R2IGAINCH1 * Q8f));
  motor[1].current = q8mul(adc_current2, (int16_t)(R2IGAIN * Q8f));
  motor[2].current = q8mul(adc_current3, (int16_t)(R2IGAIN * Q8f));
  if(operationmode == OPERATION_FRF)
  {
    if(rx_counter > 0)
    {
      motor[frfchannel].current_setpoint = rx_buffer_read();
      motor[frfchannel].setpoint_ff = 0;
      tx_buffer_write(motor[frfchannel].current);
    }
    else
    {
      motor[frfchannel].current_setpoint = 0;
    }
  }
  // compute PI controller based on current setpoint, actual measured current and feed forward
  currentPI(&motor[0]);
  currentPI(&motor[1]);
  currentPI(&motor[2]);
  if(ADC2_CH2 > KILLVOLTAGE)
  {
    motor[0].enabled = motor[1].enabled = motor[2].enabled = 0;
  }
  // if not in operational state brake or tristate motors
  if(!motor[0].enabled)
  {
    motor[0].cc_integral = 0;
    motor[0].cc_pwm = 0;
    if(motor[0].tristate) clear_drvena(DRVENA1);
  } else set_drvena(DRVENA1);
  if(!motor[1].enabled)
  {
    motor[1].cc_integral = 0;
    motor[1].cc_pwm = 0;
    if(motor[1].tristate) clear_drvena(DRVENA2);
  } else set_drvena(DRVENA2);
  if(!motor[2].enabled)
  {
    motor[2].cc_integral = 0;
    motor[2].cc_pwm = 0;
    if(motor[2].tristate) clear_drvena(DRVENA3);
  } else set_drvena(DRVENA3);
  if(App.state & APPSTATE_OUTPUT)
  {
    update_PWM();
  }
  else
  {
    clear_PWM();
  }
  uart_checkrx();
  uart_checktx();
  interrupt_acknowledge(INTPWM);
}

static inline void encoder_calculations(motor_t *motor)
{
    int32_t delta_pos, delta_time;
    int32_t velo, part;

    delta_pos = (motor->position - motor->prev_position) * motor->encoder_dir;
    delta_time = motor->poscaptime - motor->prev_poscaptime;
    if(delta_time > VELTIMELIMIT)
    {
      // velocity calcultation in two parts to keep temporary values in 32bit
      // !! changing to 64bits or float will engage lib functions that disable interrupts
      // !! thus leading to large jitter in i_handler_pwm
      part = (int32_t)(CPU_CLK * 2.0f * PI_FLOAT) / motor->encoderincrements;
      velo = (delta_pos * part * 10) / delta_time;
    } else velo = 0;
    // velocity in 0.1rad*s-1 units
    motor->velocity = (int32_t)velo;
    motor->prev_position = motor->position;
    motor->prev_poscaptime = motor->poscaptime;
}


__INTERRUPT_NATIVE void i_handler_ec(void)
{
    static int ledcnt;
    icnt++;
    txpdo1.ectime = htoes(icnt);
    ENC1_HOLD = 1;
    motor[0].position   = ENC1_COUNT;
    motor[0].poscaptime = ENC1_TIMESTAMP;
    ENC1_HOLD = 0;
    ENC2_HOLD = 1;
    motor[1].position   = ENC2_COUNT;
    motor[1].poscaptime = ENC2_TIMESTAMP;
    ENC2_HOLD = 0;
    ENC3_HOLD = 1;
    motor[2].position   = ENC3_COUNT;
    motor[2].poscaptime = ENC3_TIMESTAMP;
    ENC3_HOLD = 0;

    if(wd_cnt) wd_cnt--;
    encoder_calculations(&motor[0]);
    encoder_calculations(&motor[1]);
    encoder_calculations(&motor[2]);
    // compute feed forward for back emf
    // voltage = motor_velocity * motor_KV
    motor[0].backemf_ff = q8mul(motor[0].velocity, motor[0].kvmotor);
    motor[1].backemf_ff = q8mul(motor[1].velocity, motor[1].kvmotor);
    motor[2].backemf_ff = q8mul(motor[2].velocity, motor[2].kvmotor);
    // internal line voltage as integer value in 10mV units
    linevoltage_i = q8mul(ADC2_CH2, R2U_FP);
    // only caluculate when linevoltage > 10V
    if(linevoltage_i > LINEVOLTAGELIMIT)
    {
        // u2pwm in q8, u control in 10mV units
        u2pwm = (Q8f * PWMPER) / linevoltage_i;
    }
    else
    {
        u2pwm = (Q8f * PWMPER) / LINEVOLTAGELIMIT;
    }
    if(ledcnt++ & 0x100) toggle_digout(FRUN);
    interrupt_acknowledge(INTEC);
}

static void default_param(void)
{
  // parameter list is in little-endian
  param.m1r        = htoef2(0.611f);
  // motor speed constant (369 rpm/V 38.64 RAD/Vs 0.02587 Vs/RAD)
  param.m1kv       = htoef2(0.025f);
  param.m1pgain    = htoef2(2.0f);
  param.m1igain    = htoef2(2.0f);
  param.m1ilimit   = htoef2(0.2f);
  param.m1encdir   = 1;
  param.m1encres   = htoes(1024);
  param.m1czero    = htoes(2168);
  param.m2r        = htoef2(0.611f);
  param.m2kv       = htoef2(0.025f);
  param.m2pgain    = htoef2(2.0f);
  param.m2igain    = htoef2(2.0f);
  param.m2ilimit   = htoef2(0.2f);
  param.m2encdir   = 1;
  param.m2encres   = htoes(1024);
  param.m2czero    = htoes(1070);
  param.m3r        = htoef2(0.611f);
  param.m3kv       = htoef2(0.025f);
  param.m3pgain    = htoef2(2.0f);
  param.m3igain    = htoef2(2.0f);
  param.m3ilimit   = htoef2(0.2f);
  param.m3encdir   = 1;
  param.m3encres   = htoes(1024);
  param.m3czero    = htoes(1027);
  param.baudrate   = htoel(57600);
}

static void param2int(void)
{
  // scaling from 1mA setpoint units to 10mV voltage output in q8
  motor[0].rm2u = (int16_t)(htoef2(param.m1r) * 0.001f * 100.0f  * Q8f);
  // scaling from 0.1rad/s velocity units to 10mV voltage output in q8
  motor[0].kvmotor = (int16_t)(htoef2(param.m1kv) * 0.1f * 100.0f * Q8f) ;
  // proportional current error gain in 10V/A units in q8
  motor[0].cc_pgain = (int16_t)(htoef2(param.m1pgain) * 0.1f * Q8f);
  // integral current error gain in (20000*10/4096) -> 48.82V/A*s units in q8
  motor[0].cc_igain = (int16_t)(htoef2(param.m1igain) / 48.82f * Q8f);
  // current integral limiter in 0.001*0.00005 A*s units
  motor[0].cc_ilimit = (int32_t)(htoef2(param.m1ilimit) * 1000.0f * 20000.0f);
  motor[0].encoder_dir = param.m1encdir;
  motor[0].encoderincrements = htoes(param.m1encres);
  zero_current1 = q8mul(htoes(param.m1czero), (int16_t)(I2RGAINCH1 * Q8f));

  // scaling from 1mA setpoint units to 10mV voltage output in q8
  motor[1].rm2u = (int16_t)(htoef2(param.m2r) * 0.001f * 100.0f  * Q8f);
  // scaling from 0.1rad/s velocity units to 10mV voltage output in q8
  motor[1].kvmotor = (int16_t)(htoef2(param.m2kv) * 0.1f * 100.0f * Q8f) ;
  // proportional current error gain in 10V/A units in q8
  motor[1].cc_pgain = (int16_t)(htoef2(param.m2pgain) * 0.1f * Q8f);
  // integral current error gain in (20000*10/4096) -> 48.82V/A*s units in q8
  motor[1].cc_igain = (int16_t)(htoef2(param.m2igain) / 48.82f * Q8f);
  // current integral limiter in 0.001*0.00005 A*s units
  motor[1].cc_ilimit = (int32_t)(htoef2(param.m2ilimit) * 1000.0f * 20000.0f);
  motor[1].encoder_dir = param.m2encdir;
  motor[1].encoderincrements = htoes(param.m2encres);
  zero_current2 = q8mul(htoes(param.m2czero), (int16_t)(I2RGAIN * Q8f));

  // scaling from 1mA setpoint units to 10mV voltage output in q8
  motor[2].rm2u = (int16_t)(htoef2(param.m3r) * 0.001f * 100.0f  * Q8f);
  // scaling from 0.1rad/s velocity units to 10mV voltage output in q8
  motor[2].kvmotor = (int16_t)(htoef2(param.m3kv) * 0.1f * 100.0f * Q8f) ;
  // proportional current error gain in 10V/A units in q8
  motor[2].cc_pgain = (int16_t)(htoef2(param.m3pgain) * 0.1f * Q8f);
  // integral current error gain in (20000*10/4096) -> 48.82V/A*s units in q8
  motor[2].cc_igain = (int16_t)(htoef2(param.m3igain) / 48.82f * Q8f);
  // current integral limiter in 0.001*0.00005 A*s units
  motor[2].cc_ilimit = (int32_t)(htoef2(param.m3ilimit) * 1000.0f * 20000.0f);
  motor[2].encoder_dir = param.m3encdir;
  motor[2].encoderincrements = htoes(param.m3encres);
  zero_current3 = q8mul(htoes(param.m3czero), (int16_t)(I2RGAIN * Q8f));
}

static void init_param(void)
{
  default_param();
  param2int();
}

void init_interrupts(void)
{
  // configure PWM/ADC interrupt
  interrupt_register_native( INTPWM, (void*)NULL, i_handler_pwm );
  interrupt_configure( INTPWM, EDGE_RISING );
  interrupt_acknowledge(INTPWM);
  interrupt_enable(INTPWM);

  // configure service timer and interrupt
  TIM_TOP = SERVICEPER - 1;
  TIM_ENA = 1;
  interrupt_register_native(INTEC, (void*)NULL, i_handler_ec );
  interrupt_configure(INTEC, EDGE_RISING );
  interrupt_acknowledge(INTEC);
  interrupt_enable(INTEC);
  interrupts_enable();
}

/** Hook called from the slave stack ESC_stopoutputs to act on state changes
 * forcing us to stop outputs. Here we can set them to a safe state.
 */
void APP_safeoutput(void)
{
   motor[0].enabled = 0;
   motor[1].enabled = 0;
   motor[2].enabled = 0;
   rxpdo1.aout1 = 0;
   rxpdo1.aout2 = 0;
   rxpdo1.digital = 0;
   update_actuators();
}

void waitforESCready(void)
{
  while ((ESCvar.DLstatus & 0x0001) == 0)
  {
    ESC_read(ESCREG_DLSTATUS, (uint8_t*)&ESCvar.DLstatus, sizeof(ESCvar.DLstatus), (uint8_t*)&ESCvar.ALevent);
    ESCvar.DLstatus = etohs(ESCvar.DLstatus);
    delay_us(10);
  }
}

int32_t main(void)
{
  swplatform_init_stacks();
  // Setup post config hooks
  static esc_cfg_t config =
  {
     .pre_state_change_hook = NULL,
     .post_state_change_hook = post_state_change_hook
  };
  ESC_config ((esc_cfg_t *)&config);
  RXPDOsize = SM2_sml = sizeRXPDO();
  TXPDOsize = SM3_sml = sizeTXPDO();
  foe_init();
  delay_ms(100);
  waitforESCready();
  ESC_ALstatus(ESCinit);
  ESC_ALerror(ALERR_NONE);
  ESC_stopmbx();
  ESC_stopinput();
  ESC_stopoutput();
  init_param();
  init_actuators();
  init_sensors();
  reset_wd();
  init_interrupts();

  // cyclic application loop
  while(1)
  {
    ESC_read(ESCREG_LOCALTIME,(uint8_t*)&ESCvar.Time,sizeof(ESCvar.Time),(uint8_t*)&ESCvar.ALevent);
    ESCvar.Time=etohl(ESCvar.Time);
    ESC_state();
    if(ESC_mbxprocess())
    {
      ESC_coeprocess();
      ESC_foeprocess();
    }
    handle_RXPDO();
    handle_TXPDO();
  }
}


