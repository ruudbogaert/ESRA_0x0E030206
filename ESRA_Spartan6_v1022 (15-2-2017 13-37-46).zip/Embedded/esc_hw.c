/*
 * SOES Simple Open EtherCAT Slave
 *
 * File    : esc_hw.c
 * Version : 0.9.3
 * Date    : 1-6-2010
 * Copyright (C) 2007-2015 Arthur Ketels
 *
 * SOES is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 2 as published by the Free
 * Software Foundation.
 *
 * SOES is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * for more details.
 *
 * As a special exception, if other files instantiate templates or use macros
 * or inline functions from this file, or you compile this file and link it
 * with other works to produce a work based on this file, this file does not
 * by itself cause the resulting work to be covered by the GNU General Public
 * License. However the source code for this file must still be made available
 * in accordance with section (3) of the GNU General Public License.
 *
 * This exception does not invalidate any other reasons why a work based on
 * this file might be covered by the GNU General Public License.
 *
 * The EtherCAT Technology, the trade name and logo "EtherCAT" are the intellectual
 * property of, and protected by Beckhoff Automation GmbH.
 */
#include <stdint.h>
#include "swplatform.h"
#include "devices.h"
#include "hardware.h"
#include "utypes.h"

// CODE CHANGED FOR BIG ENDIAN
// optimized code for TSK3000 SPI port hardware

// SSI port
#define EC_SPI_BASE     drv_ec_1
#define EC_SPI_HW       Base_EC_1

inline uint8_t x_spi_transceive8( uint8_t val )
{
    SPI_DATA8(EC_SPI_HW ) = val;
    __nop();
    while((SPI_STAT(EC_SPI_HW ) & SPI_STAT_BUSY) ) __nop();
    return (uint8_t)SPI_DATA8( EC_SPI_HW );
}

#define ASSERTSPI       spi_cs_lo(EC_SPI_BASE)
#define RELEASESPI      spi_cs_hi(EC_SPI_BASE)
#define EC_SPI_WRITE(ucVal) {SPI_DATA8( EC_SPI_HW ) = ucVal;}
#define EC_SPI_READ     SPI_DATA8( EC_SPI_HW )
#define EC_SPI_WAIT     {while( SPI_STAT( EC_SPI_HW ) & SPI_STAT_BUSY ){ };}
#define EC_SPI_TRANS(ucVal) x_spi_transceive8(ucVal)

#define ESC_CMD_READ    0x02
#define ESC_CMD_READWS  0x03
#define ESC_CMD_WRITE   0x04
#define ESC_CMD_NOP     0x00
#define ESC_TERM        0xff
#define ESC_NEXT        0x00

// use read with wait state byte, needed if SPI>12Mhz or>16KB addressing
uint8_t ESC_read(uint16_t address, void *buf, uint16_t len, void *tALevent)
{
  int count;
  uint8_t *ptr;
  uint16union_t adr;
  uint8_t pstat = 0;

  ASSERTSPI;
  adr.w = address << 3;
  // swap b[0] and b[1] for big endian conversion
  ptr = tALevent;
  *(ptr + 1) = (uint8_t)EC_SPI_TRANS((uint8_t) adr.b[0]);
  *(ptr) = (uint8_t)EC_SPI_TRANS((uint8_t)(adr.b[1] + ESC_CMD_READ));
  count = len;
  ptr = buf;
  while (count-- > 1)
    {
      *(ptr++) = (uint8_t)EC_SPI_TRANS((uint8_t) ESC_NEXT);
    }
  *(ptr) = (uint8_t)EC_SPI_TRANS((uint8_t) ESC_TERM);
  RELEASESPI;
  return pstat;
}

uint8_t ESC_write(uint16_t address, void *buf, uint16_t len, void *tALevent)
{
  int wcount;
  uint8_t *ptr, *wptr;
  uint16union_t adr;

  ASSERTSPI;
  adr.w = address << 3;

  ptr = tALevent;
  wcount = len;
  // swap b[0] and b[1] for big endian conversion
  *(ptr + 1) = (uint8_t)EC_SPI_TRANS((uint8_t) adr.b[0]);
  *(ptr) = (uint8_t)EC_SPI_TRANS((uint8_t)(adr.b[1] + ESC_CMD_WRITE));
  wptr = buf;
  while (wcount--)
  {
      EC_SPI_WRITE((uint8_t) *(wptr++));
      EC_SPI_WAIT;
  }
  RELEASESPI;
  return 0;
}

