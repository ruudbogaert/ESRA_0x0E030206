#include <stdint.h>
#include <swplatform.h>
#include "boardconst.h"

#define TX_BUFFER_SIZE  100
#define RX_BUFFER_SIZE  100

int16_t               rx_buffer[RX_BUFFER_SIZE];
int                   rx_wr_index, rx_rd_index;
volatile int          rx_counter;
int                   rx_buffer_overflow;
int16_t               tx_buffer[TX_BUFFER_SIZE];
int                   tx_wr_index, tx_rd_index;
volatile int          tx_counter;

// rx_buffer is ring buffer EtherCAT to PWM interrupt
void rx_buffer_write(int16_t value)
{
  int tmpi;
  rx_buffer[rx_wr_index++] = value;
  if (rx_wr_index == RX_BUFFER_SIZE) rx_wr_index = 0;
  interrupt_disable(INTPWM);
  tmpi = ++rx_counter;
  interrupt_enable(INTPWM);
  if (tmpi == RX_BUFFER_SIZE)
  {
    interrupt_disable(INTPWM);
    rx_counter = 0;
    interrupt_enable(INTPWM);
    rx_buffer_overflow = 1;
  };
}

int16_t rx_buffer_read(void)
{
    int16_t data;
    data = rx_buffer[rx_rd_index];
    rx_buffer[rx_rd_index++] = 0x00;
    if (rx_rd_index == RX_BUFFER_SIZE) rx_rd_index = 0;
    --rx_counter;
    return data;
}

int rxfree(void)
{
    return RX_BUFFER_SIZE - rx_counter;
}

// tx_buffer is ring buffer PWM interrupt generated data to EtherCAT
int16_t tx_buffer_read(void)
{
    int16_t data;
    data = tx_buffer[tx_rd_index++];
    if (tx_rd_index == TX_BUFFER_SIZE) tx_rd_index = 0;
    interrupt_disable(INTPWM);
    --tx_counter;
    interrupt_enable(INTPWM);
    return data;
}

void tx_buffer_write(int16_t value)
{
    tx_buffer[tx_wr_index++] = value;
    if (tx_wr_index == TX_BUFFER_SIZE) tx_wr_index = 0;
    ++tx_counter;
    if(tx_counter == TX_BUFFER_SIZE)
    {
      tx_counter = 0;
    }
}


