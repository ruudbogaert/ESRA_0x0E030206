// filetransfer functions to upload .bin file to FPGA flash memory
// file has a maximum length of FOE_MAXDATA
// file has to start with string .name

#include <swplatform.h>
#include "esc_foe.h"

// 16 sectors of 256 blocks of 256 bytes each

#define  FOE_MAXDATA     0x100000       // 8 MBit = 1048576 Bytes
#define  PAGESPERBLOCK   256
#define  FOE_PAGESIZE    256

uint32_t flash_foe_buffer (foe_writefile_cfg_t * self, uint8_t * data)
{
   uint32_t flash_cmd_failed = 0;
   uint32_t calculated_address = self->dest_start_address + self->address_offset;

   // on a block boundary first erease the block (here 64K)
   if((calculated_address % (PAGESPERBLOCK * FOE_PAGESIZE)) == 0)
   {
     m25px0_sector_erase(drv_m25px0_1, calculated_address);
     while (m25px0_status(drv_m25px0_1) & 0x0001) __nop();
   }
   m25px0_program_page(drv_m25px0_1, calculated_address, data, FOE_PAGESIZE);
   while (m25px0_status(drv_m25px0_1) & 0x0001) __nop();
   return flash_cmd_failed;
}

void foe_init(void)
{
   static foe_writefile_cfg_t files[] =
   {
      {
         .name               = "esra_",
         .max_data           = FOE_MAXDATA,
         .dest_start_address = 0, /* + (uint32_t)&flash_start,*/
         .address_offset     = 0,
         .filepass           = 0,
         .write_function     = flash_foe_buffer   /* NULL if not used */
      }
   };

   static uint8_t fbuf[FOE_PAGESIZE];
   static foe_cfg_t config =
   {
      .buffer_size = FOE_PAGESIZE,  /* Buffer size before we flush to destination */
      .fbuffer     = (uint8_t *)&fbuf,
      .empty_write = 0xFF,
      .n_files     = 1,
      .files       = files
   };

   FOE_config ((foe_cfg_t *)&config, (foe_writefile_cfg_t *)&files);
}


