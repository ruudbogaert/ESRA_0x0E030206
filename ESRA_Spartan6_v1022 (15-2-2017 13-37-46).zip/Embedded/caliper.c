// Caliper read out function

#include <stdint.h>
#include <swplatform.h>
#include "utypes.h"

#define BUFFER_SIZE                    16
#define HI_NIBBLE(b)                   (((b) >> 4) & 0x0F)
#define LO_NIBBLE(b)                   ((b) & 0x0F)

void read_calipers(){
  static uint16_t caliper;
  char            buffer[BUFFER_SIZE];
  size_t          bytes_read;
  uint8_t         buffer_index;
  char            received_byte;
  uint8_t         address_nibble;
  uint16_t        data_nibble;

  bytes_read = uart8_read(drv_uart_1,buffer,BUFFER_SIZE);
  buffer_index = 0;
  while(buffer_index<bytes_read){
    received_byte = buffer[buffer_index];
    address_nibble = HI_NIBBLE(received_byte);
    data_nibble = (uint16_t)LO_NIBBLE(received_byte);
    data_nibble &= 0x000F;
    switch(address_nibble){
    case 0:
    case 4:
      data_nibble <<= 4;
      data_nibble &= 0x00F0;
      caliper = data_nibble;
      break;
    case 1:
    case 5:
      data_nibble &= 0x000F;
      caliper |= data_nibble;
      break;
    case 2:
    case 6:
      data_nibble <<= 12;
      data_nibble &= 0xF000;
      caliper |= data_nibble;
      break;
    case 3:
      data_nibble <<= 8;
      data_nibble &= 0x0F00;
      caliper |= data_nibble;
      txpdo1.caliper1 = caliper;
      break;
    case 7:
      data_nibble <<= 8;
      data_nibble &= 0x0F00;
      caliper |= data_nibble;
      txpdo1.caliper2 = caliper;
      break;
    }
    buffer_index++;
  }
}


