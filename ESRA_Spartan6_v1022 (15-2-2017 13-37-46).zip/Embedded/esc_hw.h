void ESC_initspi(void);
