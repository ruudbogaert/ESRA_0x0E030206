 /** \file
 * \brief
 * CoE Object Dictionary.
 *
 * Part of application, describe the slave and its process data.
 */
#include <stdint.h>
#include "version.h"
#include "esc_coe.h"
#include "utypes.h"

_ac acName1000[]="Device Type";
_ac acName1008[]="Manufacturer Device Name";
_ac acName1009[]="Manufacturer Hardware Version";
_ac acName100A[]="Manufacturer Software Version";
_ac acName1018[]="Identity Object";
_ac acName1018_01[]="Vendor ID";
_ac acName1018_02[]="Product Code";
_ac acName1018_03[]="Revision Number";
_ac acName1018_04[]="Serial Number";
_ac acNameMO[]="Mapped object";
_ac acName1600[]="Receive PDO mapping";    //RxPDO
_ac acName1A00[]="Transmit PDO mapping";   //TxPDO
_ac acName1C00[]="Sync Manager Communication type";
_ac acName1C00_01[]="Communications type SM0";
_ac acName1C00_02[]="Communications type SM1";
_ac acName1C00_03[]="Communications type SM2";
_ac acName1C00_04[]="Communications type SM3";
_ac acName1C10[]="Sync Manager 0 PDO Assignment";
_ac acName1C11[]="Sync Manager 1 PDO Assignment";
_ac acName1C12[]="Sync Manager 2 PDO Assignment";
_ac acName1C13[]="Sync Manager 3 PDO Assignment";
_ac acNameNOE[]="Number of entries";

_ac acName6000[]="TXPDO motor 1";
_ac acName6000_01[]="State";
_ac acName6000_02[]="Counter";
_ac acName6000_03[]="Timestamp";
_ac acName6000_04[]="Velocity";
_ac acName6000_05[]="Current";
_ac acName6001[]="TXPDO motor 2";
_ac acName6001_01[]="State";
_ac acName6001_02[]="Counter";
_ac acName6001_03[]="Timestamp";
_ac acName6001_04[]="Velocity";
_ac acName6001_05[]="Current";
_ac acName6002[]="TXPDO motor 3";
_ac acName6002_01[]="State";
_ac acName6002_02[]="Counter";
_ac acName6002_03[]="Timestamp";
_ac acName6002_04[]="Velocity";
_ac acName6002_05[]="Current";
_ac acName6010[]="TXPDO others";
_ac acName6010_01[]="Digital";
_ac acName6010_02[]="Caliper 1";
_ac acName6010_03[]="Caliper 2";
_ac acName6010_04[]="Force 1";
_ac acName6010_05[]="Force 2";
_ac acName6010_06[]="Force 3";
_ac acName6010_07[]="Position 1";
_ac acName6010_08[]="Position 2";
_ac acName6010_09[]="Position 3";
_ac acName6010_0A[]="Spare 1";
_ac acName6010_0B[]="Spare 2";
_ac acName6010_0C[]="Line voltage";
_ac acName6010_0D[]="EC time";
_ac acName6011[]="TXPDO serial bridge";
_ac acName6011_01[]="Status";
_ac acName6011_02[]="RX buffer";
_ac acName6020[]="TXPDO sequencer";
_ac acName6020_01[]="State";
_ac acName6020_02[]="Buffer";
_ac acName6020_03[]="Entries";
_ac acName6020_04[]="EC time";
_ac acName6021[]="TXPDO current buffer";
_ac acName6021_01[]="Current";
_ac acName7000[]="RXPDO motor 1";
_ac acName7000_01[]="Command";
_ac acName7000_02[]="Setpoint";
_ac acName7000_03[]="Feed forward";
_ac acName7001[]="RXPDO motor 2";
_ac acName7001_01[]="Command";
_ac acName7001_02[]="Setpoint";
_ac acName7001_03[]="Feed forward";
_ac acName7002[]="RXPDO motor 3";
_ac acName7002_01[]="Command";
_ac acName7002_02[]="Setpoint";
_ac acName7002_03[]="Feed forward";
_ac acName7010[]="RXPDO others";
_ac acName7010_01[]="Digital";
_ac acName7010_02[]="Analog 1";
_ac acName7010_03[]="Analog 2";
_ac acName7011[]="RXPDO serial bridge";
_ac acName7011_01[]="Control";
_ac acName7011_02[]="TX buffer";
_ac acName7020[]="RXPDO sequencer";
_ac acName7020_01[]="Command";
_ac acName7020_02[]="Entries";
_ac acName7020_03[]="Setpoint";

_ac acName8000[]="Motor 1 parameters";
_ac acName8000_01[]="Resistance [ohm]";
_ac acName8000_02[]="KV [Vs/rad]";
_ac acName8000_03[]="CC p_gain [V/A]";
_ac acName8000_04[]="CC i_gain [V/As]";
_ac acName8000_05[]="CC i_limit [As]";
_ac acName8000_06[]="Encoder direction";
_ac acName8000_07[]="Encoder resolution";
_ac acName8000_08[]="Current zero [mA]";
_ac acName8001[]="Motor 2 parameters";
_ac acName8002[]="Motor 3 parameters";
_ac acName8040[]="Internal voltages";
_ac acName8040_01[]="5V";
_ac acName8040_02[]="12V";
_ac acName8040_03[]="1.2V";
_ac acName8040_04[]="1.65V";

char ac1008_00[]="TUeES30";
char ac1009_00[]="2.0";
char ac100A_00[]="1020";

_objd SDO1000[]= {{0x00,DTYPE_UNSIGNED32,32,ATYPE_R,&acName1000[0],0x00000000}};
_objd SDO1008[]= {{0x00,DTYPE_VISIBLE_STRING,sizeof(ac1008_00)<<3,ATYPE_R,&acName1008[0],0,&ac1008_00[0]}};
_objd SDO1009[]= {{0x00,DTYPE_VISIBLE_STRING,sizeof(ac1009_00)<<3,ATYPE_R,&acName1009[0],0,&ac1009_00[0]}};
_objd SDO100A[]= {{0x00,DTYPE_VISIBLE_STRING,sizeof(ac100A_00)<<3,ATYPE_R,&acName100A[0],0,&ac100A_00[0]}};

_objd SDO1018[]=
{{0x00,DTYPE_UNSIGNED8,8,ATYPE_R,&acNameNOE[0],0x04},
  {0x01,DTYPE_UNSIGNED32,32,ATYPE_R,&acName1018_01[0],0x00000683},
  {0x02,DTYPE_UNSIGNED32,32,ATYPE_R,&acName1018_02[0],0x01366401},
  {0x03,DTYPE_UNSIGNED32,32,ATYPE_R,&acName1018_03[0],SW_VERSION},
  {0x04,DTYPE_UNSIGNED32,32,ATYPE_R,&acName1018_04[0],0x00000000}
};

_objd SDO1C00[]=
{{0x00,DTYPE_UNSIGNED8,8,ATYPE_R,&acNameNOE[0],0x04},
  {0x01,DTYPE_UNSIGNED8,8,ATYPE_R,&acName1C00_01[0],0x01},
  {0x02,DTYPE_UNSIGNED8,8,ATYPE_R,&acName1C00_02[0],0x02},
  {0x03,DTYPE_UNSIGNED8,8,ATYPE_R,&acName1C00_03[0],0x03},
  {0x04,DTYPE_UNSIGNED8,8,ATYPE_R,&acName1C00_04[0],0x04}
};

_objd SDO1C10[]={{0x00,DTYPE_UNSIGNED8,8,ATYPE_R,&acName1C10[0],0x00}};
_objd SDO1C11[]={{0x00,DTYPE_UNSIGNED8,8,ATYPE_R,&acName1C11[0],0x00}};

_objd SDO1C12[]={
  {0x00,DTYPE_UNSIGNED8,8,ATYPE_RW,&acNameNOE[0],0,&rxpdoentries},
  {0x01,DTYPE_UNSIGNED16,16,ATYPE_RW,&acNameMO[0],0,&ec_rxpdoindex}
};

_objd SDO1C13[]=
{{0x00,DTYPE_UNSIGNED8,8,ATYPE_RW,&acNameNOE[0],0,&txpdoentries},
  {0x01,DTYPE_UNSIGNED16,16,ATYPE_RW,&acNameMO[0],0,&ec_txpdoindex}
};

_objd SDO1A00[]={
  {0x00,DTYPE_UNSIGNED8 , 8,ATYPE_R,&acNameNOE[0],30},
  {0x01,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x60000108},
  {0x02,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x60000220},
  {0x03,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x60000320},
  {0x04,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x60000410},
  {0x05,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x60000510},
  {0x06,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x60010108},
  {0x07,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x60010220},
  {0x08,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x60010320},
  {0x09,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x60010410},
  {0x0a,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x60010510},
  {0x0b,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x60020108},
  {0x0c,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x60020220},
  {0x0d,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x60020320},
  {0x0e,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x60020410},
  {0x0f,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x60020510},
  {0x10,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x60100108},
  {0x11,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x60100210},
  {0x12,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x60100310},
  {0x13,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x60100410},
  {0x14,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x60100510},
  {0x15,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x60100610},
  {0x16,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x60100710},
  {0x17,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x60100810},
  {0x18,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x60100910},
  {0x19,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x60100A10},
  {0x1A,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x60100B10},
  {0x1B,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x60100C10},
  {0x1C,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x60100D10},
  {0x1D,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x60110110},
  {0x1E,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x60110200 + (SER_MAXBUF * 8)}
};
_objd SDO1A01[]={
  {0x00,DTYPE_UNSIGNED8 , 8,ATYPE_R,&acNameNOE[0], 6},
  {0x01,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x60200108},
  {0x02,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x60200208},
  {0x03,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x60200308},
  {0x04,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x60200410},
  {0x05,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x602101B0},
  {0x06,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x602102B0}
};

_objd SDO6000[]={
  {0x00,DTYPE_UNSIGNED8 , 8,ATYPE_R,&acNameNOE[0]    ,5},
  {0x01,DTYPE_UNSIGNED8 , 8,ATYPE_R,&acName6000_01[0],0,&(txpdo1.mstate1)},
  {0x02,DTYPE_UNSIGNED32,32,ATYPE_R,&acName6000_02[0],0,&(txpdo1.count1)},
  {0x03,DTYPE_UNSIGNED32,32,ATYPE_R,&acName6000_03[0],0,&(txpdo1.timestamp1)},
  {0x04,DTYPE_INTEGER16 ,16,ATYPE_R,&acName6000_04[0],0,&(txpdo1.velocity1)},
  {0x05,DTYPE_INTEGER16 ,16,ATYPE_R,&acName6000_05[0],0,&(txpdo1.current1)}
};
_objd SDO6001[]={
  {0x00,DTYPE_UNSIGNED8 , 8,ATYPE_R,&acNameNOE[0]    ,5},
  {0x01,DTYPE_UNSIGNED8 , 8,ATYPE_R,&acName6001_01[0],0,&(txpdo1.mstate2)},
  {0x02,DTYPE_UNSIGNED32,32,ATYPE_R,&acName6001_02[0],0,&(txpdo1.count2)},
  {0x03,DTYPE_UNSIGNED32,32,ATYPE_R,&acName6001_03[0],0,&(txpdo1.timestamp2)},
  {0x04,DTYPE_INTEGER16 ,16,ATYPE_R,&acName6001_04[0],0,&(txpdo1.velocity2)},
  {0x05,DTYPE_INTEGER16 ,16,ATYPE_R,&acName6001_05[0],0,&(txpdo1.current2)}
};
_objd SDO6002[]={
  {0x00,DTYPE_UNSIGNED8 , 8,ATYPE_R,&acNameNOE[0]    ,5},
  {0x01,DTYPE_UNSIGNED8 , 8,ATYPE_R,&acName6002_01[0],0,&(txpdo1.mstate3)},
  {0x02,DTYPE_UNSIGNED32,32,ATYPE_R,&acName6002_02[0],0,&(txpdo1.count3)},
  {0x03,DTYPE_UNSIGNED32,32,ATYPE_R,&acName6002_03[0],0,&(txpdo1.timestamp3)},
  {0x04,DTYPE_INTEGER16 ,16,ATYPE_R,&acName6002_04[0],0,&(txpdo1.velocity3)},
  {0x05,DTYPE_INTEGER16 ,16,ATYPE_R,&acName6002_05[0],0,&(txpdo1.current3)}
};
_objd SDO6010[]={
  {0x00,DTYPE_UNSIGNED8 , 8,ATYPE_R,&acNameNOE[0]    ,13},
  {0x01,DTYPE_UNSIGNED8 , 8,ATYPE_R,&acName6010_01[0],0,&(txpdo1.digital)},
  {0x02,DTYPE_UNSIGNED16,16,ATYPE_R,&acName6010_02[0],0,&(txpdo1.caliper1)},
  {0x03,DTYPE_UNSIGNED16,16,ATYPE_R,&acName6010_03[0],0,&(txpdo1.caliper2)},
  {0x04,DTYPE_UNSIGNED16,16,ATYPE_R,&acName6010_04[0],0,&(txpdo1.force1)},
  {0x05,DTYPE_UNSIGNED16,16,ATYPE_R,&acName6010_05[0],0,&(txpdo1.force2)},
  {0x06,DTYPE_UNSIGNED16,16,ATYPE_R,&acName6010_06[0],0,&(txpdo1.force3)},
  {0x07,DTYPE_UNSIGNED16,16,ATYPE_R,&acName6010_07[0],0,&(txpdo1.pos1)},
  {0x08,DTYPE_UNSIGNED16,16,ATYPE_R,&acName6010_08[0],0,&(txpdo1.pos2)},
  {0x09,DTYPE_UNSIGNED16,16,ATYPE_R,&acName6010_09[0],0,&(txpdo1.pos3)},
  {0x0A,DTYPE_UNSIGNED16,16,ATYPE_R,&acName6010_0A[0],0,&(txpdo1.analog1)},
  {0x0B,DTYPE_UNSIGNED16,16,ATYPE_R,&acName6010_0B[0],0,&(txpdo1.analog2)},
  {0x0C,DTYPE_UNSIGNED16,16,ATYPE_R,&acName6010_0C[0],0,&(txpdo1.linevoltage)},
  {0x0D,DTYPE_UNSIGNED16,16,ATYPE_R,&acName6010_0D[0],0,&(txpdo1.ectime)}
};
_objd SDO6011[]={
  {0x00,DTYPE_UNSIGNED8 , 8,ATYPE_R,&acNameNOE[0]    ,2},
  {0x01,DTYPE_UNSIGNED16   ,  16,ATYPE_R,&acName6011_01[0],0,&(txpdo1.sstatus)},
  {0x02,DTYPE_OCTET_STRING , (SER_MAXBUF * 8),ATYPE_R,&acName6011_02[0],0,&(txpdo1.srxbuf[0])}
};
_objd SDO6020[]={
  {0x00,DTYPE_UNSIGNED8 , 8,ATYPE_R,&acNameNOE[0]    ,4},
  {0x01,DTYPE_UNSIGNED8 , 8,ATYPE_R,&acName6020_01[0],0,&(txpdo2.mstate)},
  {0x02,DTYPE_UNSIGNED8 , 8,ATYPE_R,&acName6020_02[0],0,&(txpdo2.buffer)},
  {0x03,DTYPE_UNSIGNED8 , 8,ATYPE_R,&acName6020_03[0],0,&(txpdo2.entries)},
  {0x04,DTYPE_UNSIGNED16,16,ATYPE_R,&acName6020_04[0],0,&(txpdo2.ectime)}
};
_objd SDO6021[]={
  {0x00,DTYPE_UNSIGNED8 , 8,ATYPE_R,&acNameNOE[0]    ,2},
  {0x01,DTYPE_OCTET_STRING ,0xb0,ATYPE_R,&acName6021_01[0],0,&(txpdo2.current[0])},
  {0x02,DTYPE_OCTET_STRING ,0xb0,ATYPE_R,&acName6021_01[0],0,&(txpdo2.current[11])}
};

_objd SDO1600[]={
  {0x00,DTYPE_UNSIGNED8 , 8,ATYPE_R,&acNameNOE[0], 14},
  {0x01,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x70000108},
  {0x02,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x70000210},
  {0x03,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x70000310},
  {0x04,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x70010108},
  {0x05,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x70010210},
  {0x06,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x70010310},
  {0x07,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x70020108},
  {0x08,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x70020210},
  {0x09,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x70020310},
  {0x0A,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x70100108},
  {0x0B,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x70100210},
  {0x0C,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x70100310},
  {0x0D,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x70110110},
  {0x0E,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x70110200 + (SER_MAXBUF * 8)}
};
_objd SDO1601[]={
  {0x00,DTYPE_UNSIGNED8 , 8,ATYPE_R,&acNameNOE[0], 4},
  {0x01,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x70200108},
  {0x02,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x70200208},
  {0x03,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x702003B0},
  {0x04,DTYPE_UNSIGNED32,32,ATYPE_R,&acNameMO[0] ,0x702004B0},
};

_objd SDO7000[]={
  {0x00,DTYPE_UNSIGNED8 , 8,ATYPE_R ,&acNameNOE[0], 3},
  {0x01,DTYPE_UNSIGNED8 , 8,ATYPE_RW,&acName7000_01[0],0,&(rxpdo1.mcom1)},
  {0x02,DTYPE_INTEGER16 ,16,ATYPE_RW,&acName7000_02[0],0,&(rxpdo1.setpoint1)},
  {0x03,DTYPE_INTEGER16 ,16,ATYPE_RW,&acName7000_03[0],0,&(rxpdo1.ff1)}
};
_objd SDO7001[]={
  {0x00,DTYPE_UNSIGNED8 , 8,ATYPE_R ,&acNameNOE[0], 3},
  {0x01,DTYPE_UNSIGNED8 , 8,ATYPE_RW,&acName7001_01[0],0,&(rxpdo1.mcom2)},
  {0x02,DTYPE_INTEGER16 ,16,ATYPE_RW,&acName7001_02[0],0,&(rxpdo1.setpoint2)},
  {0x03,DTYPE_INTEGER16 ,16,ATYPE_RW,&acName7001_03[0],0,&(rxpdo1.ff2)}
};
_objd SDO7002[]={
  {0x00,DTYPE_UNSIGNED8 , 8,ATYPE_R ,&acNameNOE[0], 3},
  {0x01,DTYPE_UNSIGNED8 , 8,ATYPE_RW,&acName7002_01[0],0,&(rxpdo1.mcom3)},
  {0x02,DTYPE_INTEGER16 ,16,ATYPE_RW,&acName7002_02[0],0,&(rxpdo1.setpoint3)},
  {0x03,DTYPE_INTEGER16 ,16,ATYPE_RW,&acName7002_03[0],0,&(rxpdo1.ff3)}
};
_objd SDO7010[]={
  {0x00,DTYPE_UNSIGNED8 , 8,ATYPE_R ,&acNameNOE[0], 3},
  {0x01,DTYPE_UNSIGNED8 , 8,ATYPE_RW,&acName7010_01[0],0,&(rxpdo1.digital)},
  {0x02,DTYPE_INTEGER16 ,16,ATYPE_RW,&acName7010_02[0],0,&(rxpdo1.aout1)},
  {0x03,DTYPE_INTEGER16 ,16,ATYPE_RW,&acName7010_03[0],0,&(rxpdo1.aout2)}
};
_objd SDO7011[]={
  {0x00,DTYPE_UNSIGNED8 , 8,ATYPE_R,&acNameNOE[0]    ,2},
  {0x01,DTYPE_UNSIGNED16   ,  16,ATYPE_RW,&acName7011_01[0],0,&(rxpdo1.scontrol)},
  {0x02,DTYPE_OCTET_STRING , (SER_MAXBUF * 8),ATYPE_RW,&acName7011_02[0],0,&(rxpdo1.stxbuf[0])}
};
_objd SDO7020[]={
  {0x00,DTYPE_UNSIGNED8 , 8,ATYPE_R ,&acNameNOE[0], 4},
  {0x01,DTYPE_UNSIGNED8 , 8,ATYPE_RW,&acName7020_01[0],0,&(rxpdo2.mcom)},
  {0x02,DTYPE_UNSIGNED8 , 8,ATYPE_RW,&acName7020_02[0],0,&(rxpdo2.entries)},
  {0x03,DTYPE_OCTET_STRING ,0xb0,ATYPE_RW,&acName7020_03[0],0,&(rxpdo2.setpoint[0])},
  {0x04,DTYPE_OCTET_STRING ,0xb0,ATYPE_RW,&acName7020_03[0],0,&(rxpdo2.setpoint[11])}
};

_objd SDO8000[]={
  {0x00,DTYPE_UNSIGNED8 , 8,ATYPE_R ,&acNameNOE[0], 8},
  {0x01,DTYPE_REAL32    ,32,ATYPE_RW,&acName8000_01[0],0,&(param.m1r)},
  {0x02,DTYPE_REAL32    ,32,ATYPE_RW,&acName8000_02[0],0,&(param.m1kv)},
  {0x03,DTYPE_REAL32    ,32,ATYPE_RW,&acName8000_03[0],0,&(param.m1pgain)},
  {0x04,DTYPE_REAL32    ,32,ATYPE_RW,&acName8000_04[0],0,&(param.m1igain)},
  {0x05,DTYPE_REAL32    ,32,ATYPE_RW,&acName8000_05[0],0,&(param.m1ilimit)},
  {0x06,DTYPE_INTEGER8  , 8,ATYPE_RW,&acName8000_06[0],0,&(param.m1encdir)},
  {0x07,DTYPE_INTEGER16 ,16,ATYPE_RW,&acName8000_07[0],0,&(param.m1encres)},
  {0x08,DTYPE_INTEGER16 ,16,ATYPE_RW,&acName8000_08[0],0,&(param.m1czero)}
};
_objd SDO8001[]={
  {0x00,DTYPE_UNSIGNED8 , 8,ATYPE_R ,&acNameNOE[0], 8},
  {0x01,DTYPE_REAL32    ,32,ATYPE_RW,&acName8000_01[0],0,&(param.m2r)},
  {0x02,DTYPE_REAL32    ,32,ATYPE_RW,&acName8000_02[0],0,&(param.m2kv)},
  {0x03,DTYPE_REAL32    ,32,ATYPE_RW,&acName8000_03[0],0,&(param.m2pgain)},
  {0x04,DTYPE_REAL32    ,32,ATYPE_RW,&acName8000_04[0],0,&(param.m2igain)},
  {0x05,DTYPE_REAL32    ,32,ATYPE_RW,&acName8000_05[0],0,&(param.m2ilimit)},
  {0x06,DTYPE_INTEGER8  , 8,ATYPE_RW,&acName8000_06[0],0,&(param.m2encdir)},
  {0x07,DTYPE_INTEGER16 ,16,ATYPE_RW,&acName8000_07[0],0,&(param.m2encres)},
  {0x08,DTYPE_INTEGER16 ,16,ATYPE_RW,&acName8000_08[0],0,&(param.m2czero)}
};
_objd SDO8002[]={
  {0x00,DTYPE_UNSIGNED8 , 8,ATYPE_R ,&acNameNOE[0], 8},
  {0x01,DTYPE_REAL32    ,32,ATYPE_RW,&acName8000_01[0],0,&(param.m3r)},
  {0x02,DTYPE_REAL32    ,32,ATYPE_RW,&acName8000_02[0],0,&(param.m3kv)},
  {0x03,DTYPE_REAL32    ,32,ATYPE_RW,&acName8000_03[0],0,&(param.m3pgain)},
  {0x04,DTYPE_REAL32    ,32,ATYPE_RW,&acName8000_04[0],0,&(param.m3igain)},
  {0x05,DTYPE_REAL32    ,32,ATYPE_RW,&acName8000_05[0],0,&(param.m3ilimit)},
  {0x06,DTYPE_INTEGER8  , 8,ATYPE_RW,&acName8000_06[0],0,&(param.m3encdir)},
  {0x07,DTYPE_INTEGER16 ,16,ATYPE_RW,&acName8000_07[0],0,&(param.m3encres)},
  {0x08,DTYPE_INTEGER16 ,16,ATYPE_RW,&acName8000_08[0],0,&(param.m3czero)}
};
_objd SDO8040[]={
  {0x00,DTYPE_UNSIGNED8 , 8,ATYPE_R ,&acNameNOE[0], 4},
  {0x01,DTYPE_UNSIGNED16,16,ATYPE_R ,&acName8040_01[0],0,&(ivalue.v5)},
  {0x02,DTYPE_UNSIGNED16,16,ATYPE_R ,&acName8040_02[0],0,&(ivalue.v12)},
  {0x03,DTYPE_UNSIGNED16,16,ATYPE_R ,&acName8040_03[0],0,&(ivalue.v1_2)},
  {0x04,DTYPE_UNSIGNED16,16,ATYPE_R ,&acName8040_04[0],0,&(ivalue.v1_65)}
};

_objectlist SDOobjects[]={
  {0x1000,OTYPE_VAR     , 0,0,&acName1000[0],&SDO1000[0]},
  {0x1008,OTYPE_VAR     , 0,0,&acName1008[0],&SDO1008[0]},
  {0x1009,OTYPE_VAR     , 0,0,&acName1009[0],&SDO1009[0]},
  {0x100A,OTYPE_VAR     , 0,0,&acName100A[0],&SDO100A[0]},
  {0x1018,OTYPE_RECORD  , 4,0,&acName1018[0],&SDO1018[0]},
  {0x1600,OTYPE_RECORD  ,14,0,&acName1600[0],&SDO1600[0]},
  {0x1601,OTYPE_RECORD  , 4,0,&acName1600[0],&SDO1601[0]},
  {0x1A00,OTYPE_RECORD  ,30,0,&acName1A00[0],&SDO1A00[0]},
  {0x1A01,OTYPE_RECORD  , 6,0,&acName1A00[0],&SDO1A01[0]},
  {0x1C00,OTYPE_ARRAY   , 4,0,&acName1C00[0],&SDO1C00[0]},
  {0x1C10,OTYPE_ARRAY   , 0,0,&acName1C10[0],&SDO1C10[0]},
  {0x1C11,OTYPE_ARRAY   , 0,0,&acName1C11[0],&SDO1C11[0]},
  {0x1C12,OTYPE_ARRAY   , 1,0,&acName1C12[0],&SDO1C12[0]},
  {0x1C13,OTYPE_ARRAY   , 1,0,&acName1C13[0],&SDO1C13[0]},
  {0x6000,OTYPE_RECORD  , 5,0,&acName6000[0],&SDO6000[0]},
  {0x6001,OTYPE_RECORD  , 5,0,&acName6001[0],&SDO6001[0]},
  {0x6002,OTYPE_RECORD  , 5,0,&acName6002[0],&SDO6002[0]},
  {0x6010,OTYPE_RECORD  ,13,0,&acName6010[0],&SDO6010[0]},
  {0x6011,OTYPE_RECORD  , 2,0,&acName6011[0],&SDO6011[0]},
  {0x6020,OTYPE_RECORD  , 4,0,&acName6020[0],&SDO6020[0]},
  {0x6021,OTYPE_ARRAY   , 2,0,&acName6021[0],&SDO6021[0]},
  {0x7000,OTYPE_RECORD  , 3,0,&acName7000[0],&SDO7000[0]},
  {0x7001,OTYPE_RECORD  , 3,0,&acName7001[0],&SDO7001[0]},
  {0x7002,OTYPE_RECORD  , 3,0,&acName7002[0],&SDO7002[0]},
  {0x7010,OTYPE_RECORD  , 3,0,&acName7010[0],&SDO7010[0]},
  {0x7011,OTYPE_RECORD  , 2,0,&acName7011[0],&SDO7011[0]},
  {0x7020,OTYPE_RECORD  , 4,0,&acName7020[0],&SDO7020[0]},
  {0x8000,OTYPE_RECORD  , 8,0,&acName8000[0],&SDO8000[0]},
  {0x8001,OTYPE_RECORD  , 8,0,&acName8001[0],&SDO8001[0]},
  {0x8002,OTYPE_RECORD  , 8,0,&acName8002[0],&SDO8002[0]},
  {0x8040,OTYPE_RECORD  , 4,0,&acName8040[0],&SDO8040[0]},
  {0xffff,0xff,0xff,0xff,nil,nil}
};

