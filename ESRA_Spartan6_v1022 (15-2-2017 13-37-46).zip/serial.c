#include "swplatform.h"
#include "serial.h"

#define SERBASE UART_2_BASE_ADDRESS
#define INTCONTROL    2

char rx_buffer_usart[RX_BUFFER_SIZE_USART];
volatile int rx_wr_index_usart=0,rx_rd_index_usart=0;
volatile int rx_counter_usart=0;
int rx_buffer_overflow_usart=0;
char tx_buffer_usart[TX_BUFFER_SIZE_USART];
volatile int tx_wr_index_usart=0,tx_rd_index_usart=0;
volatile int tx_counter_usart=0;
int rx_busy_usart;
static int ser_keep;

#define SER_RXAVAIL(basea)      (UART8_STATUS(basea) & UART8_STATUS_RXNEMPTY)
#define SER_TXEMPTY(basea)      (UART8_STATUS(basea) & UART8_STATUS_TXSHEMPTY)
#define SER_GETCHAR(basea)      UART8_SBUF(basea)
#define SER_TXFREE(basea)       !(UART8_STATUS(basea) & UART8_STATUS_TXFULL)
#define SER_PUTCHAR(basea, val) (UART8_SBUF(basea) = val)
#define SER_RS485ON             {IOPORT_BASE8(GPIO_1_BASE_ADDRESS)[GPIO_1_TXENA] = 1;}
//{UART8_LCR(basea) |= UART8_LCR_FORCERTS | UART8_LCR_RTSVAL;}
#define SER_RS485OFF            {IOPORT_BASE8(GPIO_1_BASE_ADDRESS)[GPIO_1_TXENA] = 0;}
//{UART8_LCR(basea) &= !UART8_LCR_RTSVAL;}

static inline void int_enable (void)
{
    __mtc0( __mfc0(TSK3000_COP_Status) | TSK3000_Status_InterruptEnable ,TSK3000_COP_Status);
}

static inline void int_disable (void)
{
    __mtc0( __mfc0(TSK3000_COP_Status) & ~TSK3000_Status_InterruptEnable, TSK3000_COP_Status );
    __nop();
    __nop();
    __nop();
}


void uart_reset(void)
{
    interrupt_disable(INTCONTROL);
    uart_checkrx();
    rx_counter_usart = 0;
    rx_wr_index_usart = rx_rd_index_usart = 0;
    tx_counter_usart = 0;
    tx_wr_index_usart = tx_rd_index_usart = 0;
    ser_keep = 0;
    interrupt_enable(INTCONTROL);
}

// USART Receiver interrupt service routine
void uart_checkrx(void)
{
    while(SER_RXAVAIL(SERBASE))
       {
       rx_busy_usart = RX_BUSY_RESET;
       rx_buffer_usart[rx_wr_index_usart++] = (uint8_t)SER_GETCHAR(SERBASE);
       if (rx_wr_index_usart == RX_BUFFER_SIZE_USART) rx_wr_index_usart=0;
       if (++rx_counter_usart == RX_BUFFER_SIZE_USART)
          {
          rx_counter_usart=0;
          rx_buffer_overflow_usart=1;
          };
       };
    if(rx_busy_usart) rx_busy_usart--;
}

char uart_getchar(void)
{
    char data;

    while (rx_counter_usart==0);
    data=rx_buffer_usart[rx_rd_index_usart];
    rx_buffer_usart[rx_rd_index_usart++] = 0x00;
    if (rx_rd_index_usart == RX_BUFFER_SIZE_USART) rx_rd_index_usart=0;
    interrupt_disable(INTCONTROL);
    --rx_counter_usart;
    interrupt_enable(INTCONTROL);
    return data;
}

char uart_peek(int pos)
{
    int bpos = rx_rd_index_usart + pos;
    if (bpos >= RX_BUFFER_SIZE_USART)
        bpos -= RX_BUFFER_SIZE_USART;
    return rx_buffer_usart[bpos];
}

int uart_txfree(void)
{
    return TX_BUFFER_SIZE_USART - tx_counter_usart;
}

// USART Transmitter interrupt service routine
void uart_checktx(void)
{
    if(tx_counter_usart) ser_keep = 1;
    while (tx_counter_usart && SER_TXFREE(SERBASE))
       {
       SER_RS485ON;
       --tx_counter_usart;
       SER_PUTCHAR(SERBASE, tx_buffer_usart[tx_rd_index_usart++]);
       if (tx_rd_index_usart == TX_BUFFER_SIZE_USART) tx_rd_index_usart=0;
       }
    if(!tx_counter_usart && SER_TXEMPTY(SERBASE) && (!ser_keep--))
     SER_RS485OFF;
}

void uart_putchar(char c)
{
    while (tx_counter_usart == TX_BUFFER_SIZE_USART);
    tx_buffer_usart[tx_wr_index_usart++]=c;
    SER_RS485ON;
    if (tx_wr_index_usart == TX_BUFFER_SIZE_USART) tx_wr_index_usart=0;
    interrupt_disable(INTCONTROL);
    ++tx_counter_usart;
    interrupt_enable(INTCONTROL);
}


