#ifndef serial_h
#define serial_h

#define SERDRV drv_uart_2

#define RX_BUFFER_SIZE_USART 128
#define TX_BUFFER_SIZE_USART 128
#define RX_BUSY_RESET 12

extern volatile int tx_counter_usart;
extern volatile int rx_counter_usart;
extern int rx_buffer_overflow_usart;
extern int rx_busy_usart;

void uart_reset(void);
void uart_checkrx(void);
void uart_checktx(void);
char uart_getchar(void);
char uart_peek(int pos);
int uart_txfree(void);
void uart_putchar(char c);

#endif
